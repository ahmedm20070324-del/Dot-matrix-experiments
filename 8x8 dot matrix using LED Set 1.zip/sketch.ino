//Cathode is row and on port A(bottom to top)
//Anode is column and on port B(Right to left)
#define D 500000
void setup() {
  volatile char*dira,*dirb;
  dira=0x21;dirb=0x24;
  *dira=0xff;*dirb=0xff;

}

void loop() {
  volatile char*outa,*outb;
  volatile long i,j,k;
  k=1;
  outa=0x22;outb=0x25;
  for(i=7;i>=0;i--){
    *outa=0xff-k;
    *outb=1<<i;
    *outb=0x00;
    k=k*2;
  }
  k=1;
  for(i=0;i<8;i++){
    *outa=0xff-k;
    *outb=1<<i;
    *outb=0x00;
    k=k*2;
  }
  

}
