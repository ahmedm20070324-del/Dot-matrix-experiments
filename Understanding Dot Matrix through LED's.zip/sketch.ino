#define D 100000
void setup() {
  volatile char*dirf,*dirk;
  dirk=0x107;dirf=0x30;
  *dirk=0x03;*dirf=0x03;


}

void loop() {
  volatile char*outf,*outk;
  volatile long i;
  outf=0x31;outk=0x108;
  
  *outf=0x01;*outk=0x02;
  for(i=0;i<D;i++);
  *outf=0x01;*outk=0x01;
  for(i=0;i<D;i++);
  *outf=0x02;*outk=0x01;
  for(i=0;i<D;i++);
  *outf=0x02;*outk=0x02;
  for(i=0;i<D;i++);
  
}
