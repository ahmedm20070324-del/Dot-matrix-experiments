#include "matrix.h"
void setup() {
  volatile char*dira,*dirf,*dirk;
  dira=0x21;dirk=0x107;dirf=0x30;
  *dira=0x0f;*dirk=0x0f;*dirf=0x0f;
}
void del(){
  volatile long i;
  for(i=0;i<30000;i++);
}
void prob_10(){
  volatile long i;
  char A[8]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
  for(i=0;i<8;i++){
    disp(i+1,A[i],1,0x01);
    disp(i+1,A[i],2,0x02);
    disp(i+1,A[i],3,0x04);
    disp(i+1,A[i],4,0x08);
  }
}
void loop() {
  prob_10();
}
