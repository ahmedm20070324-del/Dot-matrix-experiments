
#include "matrix.h"
void del(long d){
  volatile long j;
  for(j=0;j<d;j++);
}
void setup() {
  char*dirf,*dirk,*dira;
  dirf=0x30;*dirf=0x01;
  dirk=0x107;*dirk=0x01;
  dira=0x21;*dira=0x01;
}
void text_upexit(){
  volatile long i,j;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=0;j<9;j++){
  for(i=0;i<8;i++){
    disp(i+1-j,E[i],4);
    disp(i+1-j,T[i],3);
    disp(i+1-j,A[i],2);
    disp(i+1-j,L[i],1);
    disp(9-j,0x00,4);
    disp(9-j,0x00,3);
    disp(9-j,0x00,2);
    disp(9-j,0x00,1);
  }
  del(20000);
  }
}
void text_downentry(){
  volatile long i,j;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=9;j>=0;j--){
  for(i=0;i<8;i++){
    disp(i+1+j,E[i],4);
    disp(i+1+j,T[i],3);
    disp(i+1+j,A[i],2);
    disp(i+1+j,L[i],1);
    disp(j,0x00,4);
    disp(j,0x00,3);
    disp(j,0x00,2);
    disp(j,0x00,1);
  }
  del(20000);
  }
}
void text_rightexit(){
  volatile long i,j,k;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(i=4;i>=0;i--){
    for(j=0;j<9;j++){
      for(k=0;k<8;k++){
        disp(k+1,E[k]<<j,i);
        disp(k+1,(T[k]<<j)+(E[k]>>8-j),i-1);
        disp(k+1,(A[k]<<j)+(T[k]>>8-j),i-2);
        disp(k+1,(L[k]<<j)+(A[k]>>8-j),i-3);
      }
      del(20000);
    }
  }
  empty();
}
void text_rightentry(){
  volatile long i,j,k;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=9;j>=0;j--){
   for(k=0;k<8;k++){
     disp(k+1,(E[k]<<j),1);
    }
    del(50000);
  }
  for(j=0;j<8;j++){
   for(k=0;k<8;k++){
     disp(k+1,(E[k]>>j)+(T[k]<<8-j),1);
     disp(k+1,(E[k]<<8-j),2);
    }
    del(50000);
  }
  for(j=0;j<8;j++){
   for(k=0;k<8;k++){
     disp(k+1,(T[k]>>j)+(A[k]<<8-j),1);
     disp(k+1,(E[k]>>j)+(T[k]<<8-j),2);
     disp(k+1,(E[k]<<8-j),3);
    }
    del(50000);
  }
  for(j=0;j<8;j++){
   for(k=0;k<8;k++){
     disp(k+1,(A[k]>>j)+(L[k]<<8-j),1);
     disp(k+1,(T[k]>>j)+(A[k]<<8-j),2);
     disp(k+1,(T[k]<<8-j)+(E[k]>>j),3);
     disp(k+1,(E[k]<<8-j),4);
    }
    del(50000);
  }
}
void text_leftexit(){
  volatile long i,j,k;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=0;j<9;j++){
    for(k=0;k<8;k++){
      disp(k+1,(E[k]>>j)+(T[k]<<8-j),4);
      disp(k+1,(T[k]>>j)+(A[k]<<8-j),3);
      disp(k+1,(A[k]>>j)+(L[k]<<8-j),2);
      disp(k+1,(L[k]>>j),1);
    }
      del(20000);
    }
  for(j=0;j<9;j++){
    for(k=0;k<8;k++){
      disp(k+1,(T[k]>>j)+(A[k]<<8-j),4);
      disp(k+1,(A[k]>>j)+(L[k]<<8-j),3);
      disp(k+1,(L[k]>>j),2);
    }
    del(20000);
  }
  for(j=0;j<9;j++){
    for(k=0;k<8;k++){
      disp(k+1,(A[k]>>j)+(L[k]<<8-j),4);
      disp(k+1,(L[k]>>j),3);
    }
    del(20000);
  }
  for(j=0;j<9;j++){
    for(k=0;k<8;k++){
      disp(k+1,(L[k]>>j),4);
    }
    del(20000);
  }
}
void text_leftentry(){
  volatile long i,j,k;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
    for(j=0;j<9;j++){
      for(k=0;k<8;k++){
        disp(k+1,(L[k]>>8-j),4);
      }
      del(20000);
    }
    for(j=0;j<9;j++){
      for(k=0;k<8;k++){
        disp(k+1,(L[k]<<j)+(A[k]>>8-j),4);
        disp(k+1,(L[k]>>8-j),3);
      }
      del(20000);
    }
    for(j=0;j<9;j++){
      for(k=0;k<8;k++){
        disp(k+1,(A[k]<<j)+(T[k]>>8-j),4);
        disp(k+1,(A[k]>>8-j)+(L[k]<<j),3);
        disp(k+1,(L[k]>>8-j),2);
      }
      del(20000);
    }
    for(j=0;j<9;j++){
      for(k=0;k<8;k++){
        disp(k+1,(T[k]<<j)+(E[k]>>8-j),4);
        disp(k+1,(T[k]>>8-j)+(A[k]<<j),3);
        disp(k+1,(A[k]>>8-j)+(L[k]<<j),2);
        disp(k+1,(L[k]>>8-j),1);
      }
      del(20000);
    }
}
void text_downexit(){
  volatile long i,j;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=0;j<9;j++){
  for(i=0;i<8;i++){
    disp(i+1+j,E[i],4);
    disp(i+1+j,T[i],3);
    disp(i+1+j,A[i],2);
    disp(i+1+j,L[i],1);
    disp(j,0x00,4);
    disp(j,0x00,3);
    disp(j,0x00,2);
    disp(j,0x00,1);
  }
  del(20000);
  }
}
void text_upentry(){
  volatile long i,j;
  char E[8],T[8],A[8],L[8];
  upperletter(E,T,A,L);
  for(j=9;j>=0;j--){
  for(i=0;i<8;i++){
    disp(i+1-j,E[i],4);
    disp(i+1-j,T[i],3);
    disp(i+1-j,A[i],2);
    disp(i+1-j,L[i],1);
    disp(9-j,0x00,4);
    disp(9-j,0x00,3);
    disp(9-j,0x00,2);
    disp(9-j,0x00,1);
  }
  del(20000);
  }
}
void loop() {
  text_leftentry();
  text_rightexit();
  text_upentry();
  text_rightexit();
}
