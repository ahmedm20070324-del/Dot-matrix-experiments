void letter_Wup(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
  outa=0x22;outb=0x25;
  *outa=(0x81<<k)+i;*outb=0x44;*outa=0xff;*outb=0x00;
  *outa=(0xfd<<k)+i;*outb=0x28;*outa=0xff;*outb=0x00;
  *outa=(0xfb<<k)+i;*outb=0x10;*outb=0x00;
}
void letter_Wdown(long k){
  volatile char*outa,*outb;
  volatile long i,j,l;
  i=0x80;l=0;
  for(j=0;j<k;j++){
    l+=i;
    i=i/2;
  }
  outa=0x22;outb=0x25;
  *outa=(0x81>>k)+l;*outb=0x44;*outa=0xff;*outb=0x00;
  *outa=(0xfd>>k)+l;*outb=0x28;*outa=0xff;*outb=0x00;
  *outa=(0xfb>>k)+l;*outb=0x10;*outb=0x00;
}


void letter_c(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
outa=0x22;outb=0x25;
*outa=(0xed<<k)+i;*outb=0x1c;*outb=0x00;
*outa=(0xf3<<k)+i;*outb=0x20;*outb=0x00;
}
void letter_e(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
outa=0x22;outb=0x25;
*outa=(0xfd<<k)+i;*outb=0x1c;*outb=0x00;
*outa=(0xe3<<k)+i;*outb=0x20;*outb=0x00;
*outa=(0xd7<<k)+i;*outb=0x18;*outb=0x00;
*outa=(0xef<<k)+i;*outb=0x04;*outb=0x00;
}
void letter_l(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
outa=0x22;outb=0x25;
*outa=(0x81<<k)+i;*outb=0x08;*outb=0x00;
*outa=(0xfe<<k)+i;*outb=0x1c;*outb=0x00;
*outa=(0xbf<<k)+i;*outb=0x10;*outb=0x00;
}
void letter_o(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
outa=0x22;outb=0x25;
*outa=(0xf5<<k)+i;*outb=0x18;*outb=0x00;
*outa=(0xfb<<k)+i;*outb=0x24;*outb=0x00;
}
void letter_m(long k){
  volatile char*outa,*outb;
  volatile long i,j;
  i=1;
  for(j=0;j<k;j++){
    i=i*2;
  }
  i--;
outa=0x22;outb=0x25;
*outa=(0xf9<<k)+i;*outb=0x22;*outb=0x00;
*outa=(0xf7<<k)+i;*outb=0x14;*outb=0x00;
*outa=(0xe7<<k)+i;*outb=0x20;*outb=0x00;
*outa=(0xfb<<k)+i;*outb=0x08;*outb=0x00;
}