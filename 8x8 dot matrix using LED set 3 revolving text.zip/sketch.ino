//Cathode is row and on port A(bottom to top)
//Anode is column and on port B(Right to left)
#define D 30000
#define J 10000
#include "Welcome.h"
void setup() {
  volatile char*dira,*dirb;
  dira=0x21;dirb=0x24;
  *dira=0xff;*dirb=0xff;
}

void loop() {
  volatile char*outb;
  outb=0x25;
  volatile long  i,j,k;
  for(k=8;k>=0;k--){
  for(i=0;i<D;i++){
    letter_Wup(k);
  }
  for(j=0;j<D;j++);
  }
  for(k=0;k<8;k++){
  for(i=0;i<J;i++){
    letter_Wdown(k);
  }
  for(j=0;j<J;j++);
  }
  
}

