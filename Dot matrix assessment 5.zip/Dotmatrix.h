void Dot_matrix(long address,long data){//Second Digit
  volatile char*outk,*outf,*outa;
  volatile long i;
  outk=0x108;outf=0x31;outa=0x22;
  *outk=0x00;//CS set to low for listening to instructions
  for(i=7;i>=0;i--){//stored from Most significant bit to least significant bit
  *outa=0x00;//Clock goes low
  if((address>>i)&0x01){
    *outf=0x01;
  }
  else{
    *outf=0x00;
  }
  *outa=0x01;//Clock goes high and stores the bit
  }
  for(i=7;i>=0;i--){//stored from Most significant bit to least significant bit
  *outa=0x00;//Clock goes low
  if((data>>i)&0x01){
    *outf=0x01;
  }
  else{
    *outf=0x00;
  }
  *outa=0x01;//Clock goes high and stores the bit
  }
  *outk=0x01;//Executes instructions

}