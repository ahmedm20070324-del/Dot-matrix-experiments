#include "twoDotmatrix.h"
#include "Dotmatrix.h"
void setup(){
  volatile char*dirf,*dira,*dirk;
  dirf=0x30;dirk=0x107;dira=0x21;
  *dirf=0x01;*dirk=0x01;*dira=0x01;
}
void loop(){
  SB();
  delay(1000);
  twelve();
  delay(1000);
}

void SB(){
  volatile long i;
  long k;
  Dot_matrix_dual(1,0x1c);
  Dot_matrix_dual(2,0x22);
  k=0x02;
  for(i=3;i<7;i++){
    Dot_matrix_dual(i,k);
    k=k*2;
  }
  Dot_matrix_dual(7,0x22);
  Dot_matrix_dual(8,0x1c);
  for(i=1;i<9;i=i+7){
    Dot_matrix(i,0x1c);
  }
  for(i=2;i<8;i=i+1){
    Dot_matrix(i,0x24);
    if(i==3){
      i=i+1;
    }
  }
  Dot_matrix(4,0x1c);
}
void twelve(){
  volatile long i;
  long k;
  for(i=3;i<8;i++){
    Dot_matrix_dual(i,0x08);
  }
  Dot_matrix_dual(8,0x1c);
  Dot_matrix_dual(1,0x0c);
  Dot_matrix_dual(2,0x0a);
  Dot_matrix(1,0x1c);
  Dot_matrix(2,0x22);
  k=0x20;
  for(i=3;i<8;i++){
    Dot_matrix(i,k);
    k=k/2;
  }
  Dot_matrix(8,0x3e);
}

