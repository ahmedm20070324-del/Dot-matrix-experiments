void first(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void second(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void third(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void fourth(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void fifth(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void sixth(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  for(i=7;i>=0;i--){*outa=0x00;*outf=0x00;*outa=0x01;}
  *outk=0x01;
}
void last(long address,long data){
  volatile long i,j;
  volatile char*outa,*outf,*outk;
  outk=0x108;outa=0x22;outf=0x31;
  *outk=0x00;
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((address>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){*outf=0x01;}
    else{*outf=0x00;}
    *outa=0x01;
  }
  *outk=0x01;
}
disp(long address,long data,long a){
  if(a==1){first(address,data);}
  if(a==2){second(address,data);}
  if(a==3){third(address,data);}
  if(a==4){fourth(address,data);}
  if(a==5){fifth(address,data);}
  if(a==6){sixth(address,data);}
  if(a==7){last(address,data);}
}
void empty(){
  volatile long i;
  for(i=0;i<8;i++){
    disp(i+1,0x00,7);
    disp(i+1,0x00,6);
    disp(i+1,0x00,5);
    disp(i+1,0x00,4);
    disp(i+1,0x00,3);
    disp(i+1,0x00,2);
    disp(i+1,0x00,1);
  }
}