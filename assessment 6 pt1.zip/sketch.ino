#include "matrix.h"
#include "letter.h"
void setup() {
  volatile char*dira,*dirf,*dirk;
  dira=0x21;dirf=0x30;dirk=0x107;
  *dira=0x01;*dirf=0x01,*dirk=0x01;
}
void del(){
  volatile long j;
  for(j=0;j<20000;j++);
}
void prob_1(){
  volatile long i,j,k;
  char A[8],B[8],C[8],D[8],E[8],F[8],G[8];
  upperletter(A);
  loweralpha(B,C,D,E,F,G);
  for(k=8;k>=1;k--){
    for(j=0;j<7;j++){
      for(i=0;i<8;i++){
        disp(i+1,(G[i]>>8-j),8-k);
        disp(i+1,(F[i]>>8-j)+(G[i]<<j),7-k);
        disp(i+1,(E[i]>>8-j)+(F[i]<<j),6-k);
        disp(i+1,(D[i]>>8-j)+(E[i]<<j),5-k);
        disp(i+1,(C[i]>>8-j)+(D[i]<<j),4-k);
        disp(i+1,(B[i]>>8-j)+(C[i]<<j),3-k);
        disp(i+1,(A[i]>>8-j)+(B[i]<<j),2-k);
      }
      del();
    }
  }
  for(k=0;k<8;k++){
    for(j=0;j<7;j++){
      for(i=0;i<8;i++){
        disp(i+1,(G[i]<<j)+(F[i]>>8-j),k+7);
        disp(i+1,(F[i]<<j)+(E[i]>>8-j),k+6);
        disp(i+1,(E[i]<<j)+(D[i]>>8-j),k+5);
        disp(i+1,(D[i]<<j)+(C[i]>>8-j),k+4);
        disp(i+1,(C[i]<<j)+(B[i]>>8-j),k+3);
        disp(i+1,(B[i]<<j)+(A[i]>>8-j),k+2);
        disp(i+1,(A[i]<<j),k+1);
        disp(i+1,0x00,k);
      }
      del();
    }
  }
}
void prob_2(){
  volatile long i,j,k;
  char A[8],B[8],C[8],D[8],E[8],F[8],G[8];
  upperletter(A);
  loweralpha(B,C,D,E,F,G);
  for(k=8;k>=1;k--){
    for(j=0;j<7;j++){
      for(i=0;i<8;i++){
        disp(i+1,(G[i]<<8-j)+(F[i]>>j),k+6);
        disp(i+1,(F[i]<<8-j)+(E[i]>>j),k+5);
        disp(i+1,(E[i]<<8-j)+(D[i]>>j),k+4);
        disp(i+1,(D[i]<<8-j)+(C[i]>>j),k+3);
        disp(i+1,(C[i]<<8-j)+(B[i]>>j),k+2);
        disp(i+1,(B[i]<<8-j)+(A[i]>>j),k+1);
        disp(i+1,(A[i]<<8-j),k);
      }
      del();
    }
  }
  for(k=8;k>=0;k--){
    for(j=0;j<8;j++){
      for(i=0;i<8;i++){
        disp(i+1,(G[i]>>j),k-1);
        disp(i+1,(F[i]>>j)+(G[i]<<8-j),k-2);
        disp(i+1,(E[i]>>j)+(F[i]<<8-j),k-3);
        disp(i+1,(D[i]>>j)+(E[i]<<8-j),k-4);
        disp(i+1,(C[i]>>j)+(D[i]<<8-j),k-5);
        disp(i+1,(B[i]>>j)+(C[i]<<8-j),k-6);
        disp(i+1,(A[i]>>j)+(B[i]<<8-j),k-7);
      }
      del();
    }
  }
}
void prob_3(){
  volatile long i,j,k;
  char A[8],B[8],C[8],D[8],E[8],F[8],G[8];
  upperletter(A);
  loweralpha(B,C,D,E,F,G);
  for(j=8;j>=0;j--){
    for(i=0;i<8;i++){
      disp(i+1,G[i],7);
      disp(i+1,F[i],6);
      disp(i+1,E[i],5);
      disp(i+1-j,D[i],4);
      disp(i+1-j,C[i],3);
      disp(i+1-j,B[i],2);
      disp(i+1-j,A[i],1);
    }
    del();
  }
  for(k=8;k>=0;k--){
    for(j=0;j<8;j++){
      for(i=0;i<8;i++){
        disp(i+1,G[i],7);
        disp(i+1,F[i],6);
        disp(i+1,E[i],5);
        disp(i+1,(D[i]>>j),k-4);
        disp(i+1,(C[i]>>j)+(D[i]<<8-j),k-5);
        disp(i+1,(B[i]>>j)+(C[i]<<8-j),k-6);
        disp(i+1,(A[i]>>j)+(B[i]<<8-j),k-7);
      }
      del();
    }
  }
}
void prob_4(){
  volatile long i,j,k;
  char A[8],B[8],C[8],D[8],E[8],F[8],G[8];
  upperletter(A);
  loweralpha(B,C,D,E,F,G);
  for(j=8;j>=0;j--){
    for(i=0;i<8;i++){
      disp(i+1,G[i],7);
      disp(i+1,F[i],6);
      disp(i+1,E[i],5);
      disp(i+1+j,D[i],4);
      disp(i+1+j,C[i],3);
      disp(i+1+j,B[i],2);
      disp(i+1+j,A[i],1);
    }
    del();
  }
  for(k=8;k>=0;k--){
    for(j=0;j<8;j++){
      for(i=0;i<8;i++){
        disp(i+1,G[i],7);
        disp(i+1,F[i],6);
        disp(i+1,E[i],5);
        disp(i+1,(D[i]>>j),k-4);
        disp(i+1,(C[i]>>j)+(D[i]<<8-j),k-5);
        disp(i+1,(B[i]>>j)+(C[i]<<8-j),k-6);
        disp(i+1,(A[i]>>j)+(B[i]<<8-j),k-7);
      }
      del();
    }
  }
}
void loop() {
  prob_1();
  prob_2();
  prob_3();
  prob_4();
  empty();
}
