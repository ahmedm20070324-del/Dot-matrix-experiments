void setup(){
  volatile char*dirf,*dira,*dirk;
  dirf=0x30;dirk=0x107;dira=0x21;
  *dirf=0x01;*dirk=0x01;*dira=0x01;
}
void loop(){
  volatile long i;
  long k=0x01;
//(column=address,row=led)
for(i=8;i>=1;i--){
Dot_matrix(i,k);
k=k*2;
}
}
void Dot_matrix(long address,long data){
  volatile char*outk,*outa,*outf;
  volatile long i;
  outf=0x31;outk=0x108;outa=0x22;
  *outk=0x00;//CS set to low (Dot matrix listens to command)
  for(i=7;i>=0;i--){
    *outa=0x00;//clock is Low
    if((address>>i)&0x01){
      *outf=0x01;
    }
    else{
      *outf=0x00;
    }
    *outa=0x01;//clock goes high and stores memory
  }
  for(i=7;i>=0;i--){
    *outa=0x00;
    if((data>>i)&0x01){
      *outf=0x01;
    }
    else{
      *outf=0x00;
    }
    *outa=0x01;
  }
  *outk=0x01;//CS set to high(executes the given command)
}
